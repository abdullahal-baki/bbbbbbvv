
import json
import os
import threading
import time
import requests
from typing import Any, Dict
from datetime import date, timedelta, datetime

from payloads import *
from payment import *
from database import *

################################################################
#
# Required modules: payloads, payment, database  
#
# ---------------------------------------------------
# Required Packages: requests, sqlalchemy, flask, flask-sqlalchemy
#
##  pip install -r requirements.txt
#
################################################################

class Bot:
    def __init__(self, api_key: str):
        __VERSION__ = '0.1'
        self.API_KEY = api_key
        print("starting... ")
        self.base_url = f'https://api.telegram.org/bot{self.API_KEY}'
        self.admin_ids = ["2102187753","5531987523"]
        self.alert_date = []

    def get_updates(self,offset: int = None):
        url = f'{self.base_url}/getUpdates'
        params = {'offset': offset} if offset else {}
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            result = response.json()
            if not result.get("ok"):
                raise ValueError(f"Error in response: {result}")
            return result
        except requests.RequestException as e:
            print(f"Network error occurred: {e}")
            return {}
        except ValueError as e:
            print(f"Response error: {e}")
            return {}
    
    def send_message(self,chat_id,msg):
        send_message = f'{self.base_url}/sendMessage'
        payload={
                "chat_id":chat_id,
                "text":msg,
				"parse_mode":"Markdown"
                }
        requests.post(send_message,json=payload)
        
    def send_message_with_payload(self,payload):
        send_message = f'{self.base_url}/sendMessage'
        requests.post(send_message,json=payload)
    def send_image(self,chat_id,path,caption="new pic"):
        photo = {'photo':open(path,'rb')}
        send_img = f'{self.base_url}/sendPhoto?chat_id='+str(chat_id)+'&caption='+str(caption)+'&parse_mode=Markdown'
        requests.post(send_img,files=photo)
    def send_video(self,chat_id,path,caption="new video"):
        vid = {'video':open(path,'rb')}
        send_vid = f'{self.base_url}/sendVideo?chat_id='+str(chat_id)+'&caption='+str(caption)+'&parse_mode=Markdown'
        requests.post(send_vid,files=vid)
    
    def check_expiration(self,member):
        today_date = date.today()
        if member.membership_expire > today_date:
            print(f"Member {member.name}'s subscription is active.")
            return True
        elif member.membership_expire < today_date:
            print(f"Member {member.name}'s subscription has expired.")
            become_basic(member.telegram_id)
            self.send_message(member.telegram_id,msg="Your membership has expired.")
            return False
        else:
            return True
    
    def premium_or_not(self,chat_id):
        try:
            member = get_member(chat_id)
            member_status = member.subscription_status
            if member_status.lower() == "premium":
                check = self.check_expiration(member)
                if check:
                    return True
                else:
                    return False
            else:
                return False
        except:
            return False
    
    def send_signals(self):
        signal = get_signals()
        if signal:
            signal_body = signal.body
            signal_type = signal.data_type
            update_signal(signal.id)
            db_members_ids = get_telegram_ids()
            if signal_type == 'image':
                filepath = os.path.join('uploads/',signal.file_name)
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id):
                        self.send_image(user_id ,filepath,signal_body)
                print(f"signal: {signal_body[:10]}... sent to all premium members")
                try:
                    os.remove(filepath)
                except:
                    pass
            elif signal_type == 'video':
                filepath = os.path.join('uploads/',signal.file_name)
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id):
                        self.send_video(user_id,filepath,signal_body)
                print(f"signal: {signal_body[:10]}... sent to all premium members")
                try:
                    os.remove(filepath)
                except:
                    pass
            else:
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id):
                        self.send_message(user_id,signal_body)
                print(f"signal: {signal_body[:10]}... sent to all premium members")
            
    def send_announcements(self):
        announce = get_announcements()
        if announce:
            announce_body = announce.body
            announce_type = announce.data_type
            update_announcements(announce.id)
            db_members_ids = get_telegram_ids()
            if announce_type == 'image':
                filepath = os.path.join('uploads/',announce.file_name)
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id) == False:
                        self.send_image(user_id,filepath,announce_body)
                print(f"announce: {announce_body[:10]}... sent to free members")
                try:
                    os.remove(filepath)
                except:
                    pass
            elif announce_type == 'video':
                filepath = os.path.join('uploads/',announce.file_name)
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id) == False:
                        self.send_video(user_id,filepath,announce_body)
                print(f"announce: {announce_body[:10]}... sent to free members")
                try:
                    os.remove(filepath)
                except:
                    pass
            else:
                for user_id in db_members_ids:
                    if self.premium_or_not(user_id) == False:
                        self.send_message(user_id,announce_body)
                print(f"announce: {announce_body[:10]}... sent to free members")
    def expire_alart(self):
        try:
            today_date = date.today()
            if today_date not in self.alert_date:
                members = get_all_members()
                for member in members:
                    member_status = member.membership_expire
                    if member_status and member.subscription_status == "Premium":
                        if member_status < today_date:
                            self.send_message(member.telegram_id,msg="Your membership has expired.")
                            become_basic(member.telegram_id)
                            print(f"Member {member.name}'s subscription has expired.")
                        elif member_status == today_date:
                            self.send_message(member.telegram_id,msg="Your membership expires tomorrow")
                            print(f"Member {member.name}'s subscription expires today.")
            self.alert_date.append(today_date)
        except Exception as e:
            print(e)
            pass 
    def main(self):
        print("Ready to receive message")
        offset = None
        while True:
            self.expire_alart()
            updates = self.get_updates(offset)
            if 'result' in updates:
                for update in updates['result']:
                    result = update
                    discount = int(get_discount())
                    if discount > 0:
                        plan1_amount = 40 - ( 40*(discount / 100 ))     # 1 month
                        plan2_amount = 90 - ( 90*(discount / 100 ))     # 3 months
                        plan3_amount = 150 - ( 150*(discount / 100 ))     # 6 months
                        plan4_amount = 250 - ( 250*(discount / 100 )) # lifetime
                    else:
                        plan1_amount = 40     # 1 month
                        plan2_amount = 90    # 3 months
                        plan3_amount = 150    # 6 months
                        plan4_amount = 250    # lifetime
                    try:
                        chat_id = result["message"]["from"]["id"]
                        full_name = result["message"]["from"]["first_name"]
                            
                        reply_msg = result["message"]["text"]
                        print(f"New Message from {full_name}>{chat_id} : ",reply_msg)
                        
                        if reply_msg.lower() == "/start":
                            username = ''
                            try:
                                username = result["message"]["from"]["username"]
                            except:
                                print("Couldn't find username")
                            self.send_message_with_payload(start_payload(chat_id,full_name))
                            db_members_ids = get_telegram_ids()
                            if not str(chat_id) in db_members_ids:
                                add_member(chat_id,username,full_name)
                                print(f"Added New Member {full_name} > {chat_id}")
                                self.send_message_with_payload(main_menu(chat_id))
                                self.send_message_with_payload(subscribe_plan(chat_id,
                                                                                plan1_amount,
                                                                                plan2_amount,
                                                                                plan3_amount,
                                                                                plan4_amount,
                                                                                discount))
                            else:
                                premium_status = self.premium_or_not(chat_id)
                                if premium_status:
                                    self.send_message(chat_id,main_menu_for_member())
                                else:
                                    self.send_message_with_payload(main_menu(chat_id))
                                    self.send_message_with_payload(subscribe_plan(chat_id,
                                                                                plan1_amount,
                                                                                plan2_amount,
                                                                                plan3_amount,
                                                                                plan4_amount,
                                                                                discount))
                                
                        elif reply_msg.lower() == "/help" or reply_msg.lower() == "help":
                            help_msg = help()
                            self.send_message(chat_id,help_msg)
                            
                        elif reply_msg.lower() == "membership status" or reply_msg.lower() == "/membershipstatus":
                            premium_status = self.premium_or_not(chat_id)
                            if premium_status:
                                expire_date = get_member(chat_id).membership_expire
                                self.send_message(chat_id, msg=member_subscription_status(expire_date))
                            
                            else:
                                self.send_message_with_payload(not_subscribe(chat_id))
                                
                        elif reply_msg.lower() == "join" or reply_msg.lower() == "/join":
                            premium_status = self.premium_or_not(chat_id) 
                            if not_subscribe:
                                self.send_message_with_payload(join_channel(chat_id))
                        
                        elif reply_msg.lower() == "/subscribe":
                            premium_status = self.premium_or_not(chat_id)
                            if premium_status:
                                self.send_message(chat_id,"You are already a premium member.")
                            else:
                                self.send_message_with_payload(subscribe_plan(chat_id,
                                                                            plan1_amount,
                                                                            plan2_amount,
                                                                            plan3_amount,
                                                                            plan4_amount,
                                                                            discount))
                        
                        elif "/support" in reply_msg.lower() :
                            if len(reply_msg.split(" ")) > 1:
                                support_message = reply_msg.split("/support")[1].strip()
                                print("support_message: ",support_message)
                                support_message_tamplate = f"Support Message from {full_name}\nUser ID: {chat_id},\nMessage: {support_message}\n\nReply Back Him/Her by - \n/reply [USER ID] [REPLY MSG]"
                                for admin_id in self.admin_ids:
                                    self.send_message(admin_id,support_message_tamplate)
                            else:
                                self.send_message(chat_id,"Get Admin Support. Type:\n\n /support [Your Message]")
                        
                        elif "/reply" in reply_msg.lower():
                            if str(chat_id) in self.admin_ids:
                                raw_rply_msg = reply_msg.split("/reply")[1].strip()
                                user_id = raw_rply_msg.split(" ")[0].strip()
                                reply_back_msg = ' '.join(raw_rply_msg.split(" ")[1:])
                                reply_back_msg_tamplate = f"You Got A Reply From Admin.\n\nReply Message: {reply_back_msg}"
                                self.send_message(chat_id=user_id, msg=reply_back_msg_tamplate)
                            else:
                                self.send_message(chat_id,"You are not an admin.")
                            

                    except KeyError:
                        
                        if 'callback_query' in result.keys():
                            callback_data = result["callback_query"]["data"]
                            chat_id = result["callback_query"]["from"]["id"]
                            name = result["callback_query"]["from"]["first_name"]
                            print(f'callback from {chat_id}: ',callback_data)
                            if callback_data.lower() == "main-menu":
                                self.send_message_with_payload(start_payload(chat_id,name))                                
                                premium_status = self.premium_or_not(chat_id)
                                if premium_status:
                                    self.send_message(chat_id,main_menu_for_member())
                                else:
                                    self.send_message_with_payload(main_menu(chat_id))
                                    self.send_message_with_payload(subscribe_plan(chat_id,
                                                                                plan1_amount,
                                                                                plan2_amount,
                                                                                plan3_amount,
                                                                                plan4_amount,
                                                                                discount))
                                
                            elif callback_data.lower() == "subscribe":
                                self.send_message_with_payload(subscribe_plan(chat_id, 
                                                                            plan1_amount,
                                                                            plan2_amount,
                                                                            plan3_amount,
                                                                            plan4_amount,
                                                                            discount))
                            
                    #-----------individual plans--------------
                            
                            elif callback_data.lower() == "signals-plan-1m":
                                self.send_message_with_payload(signals_plan_1m(chat_id,amount= plan1_amount))
                                
                            elif callback_data.lower() == "signals-plan-1m-confirm":
                                pay_url,pay_id = create_payment(plan1_amount, 'USD', f'Payment from {name} for 1 month subscription')
                                if pay_url and pay_id:
                                    self.send_message_with_payload(signals_plan_confirm_message(chat_id,pay_url))
                                    t = threading.Thread(target=check_payment_status,args=(chat_id,pay_id,1)) # id,payid,month
                                    t.start()
                            
                            elif callback_data.lower() == "signals-plan-3m":
                                self.send_message_with_payload(signals_plan_3m(chat_id, amount= plan2_amount))
                                
                            elif callback_data.lower() == "signals-plan-3m-confirm":
                                pay_url,pay_id = create_payment(plan2_amount, 'USD', f'Payment from {name} for 3 month subscription')
                                if pay_url and pay_id:
                                    self.send_message_with_payload(signals_plan_confirm_message(chat_id,pay_url))
                                    t = threading.Thread(target=check_payment_status,args=(chat_id,pay_id, 3))
                                    t.start()
                            
                            elif callback_data.lower() == "signals-plan-1y":
                                self.send_message_with_payload(signals_plan_1y(chat_id,amount=plan3_amount ))
                                
                            elif callback_data.lower() == "signals-plan-1y-confirm":
                                pay_url,pay_id = create_payment(plan3_amount, 'USD', f'Payment from {name} for 12 month subscription')
                                if pay_url and pay_id:
                                    self.send_message_with_payload(signals_plan_confirm_message(chat_id,pay_url))
                                    t = threading.Thread(target=check_payment_status,args=(chat_id,pay_id,12))
                                    t.start()
                            
                            elif callback_data.lower() == "signals-plan-lifetime":
                                self.send_message_with_payload(signals_plan_lifetime(chat_id, amount= plan4_amount))
                                
                            elif callback_data.lower() == "signals-plan-lifetime-confirm":
                                pay_url,pay_id = create_payment(plan4_amount, 'USD', f'Payment from {name} for lifetime subscription')
                                if pay_url and pay_id:
                                    self.send_message_with_payload(signals_plan_confirm_message(chat_id,pay_url))
                                    t = threading.Thread(target=check_payment_status,args=(chat_id,pay_id,9999))
                                    t.start()
                                    
                    offset = update['update_id'] + 1
            
            signal_thread = threading.Thread(target=self.send_signals)
            signal_thread.start()
            announce_thread = threading.Thread(target=self.send_announcements)
            announce_thread.start()
            
if __name__ == '__main__':
    # b = Bot(api_key="7422812090:AAE-4-wDJxtoSasMQIKiHsEiNE7K7wX3NUc")
    # b.main()
    
##---tester bot
    b = Bot(api_key="7089877258:AAFvL5ShLK7EvQ1k59iKYln5iXTfy0ibl_I")
    b.main()
    
# https://api.telegram.org/bot7089877258:AAFvL5ShLK7EvQ1k59iKYln5iXTfy0ibl_I/getUpdates
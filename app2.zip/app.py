from datetime import datetime
import os
import threading
from flask import Flask,render_template, template_rendered, flash, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import secrets      
import base64

secret_key = secrets.token_hex(16)
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.secret_key = secret_key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'     #-- config database path 
db = SQLAlchemy(app)

class Members(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    telegram_id = db.Column(db.String(255), unique=True)
    username = db.Column(db.String)
    name = db.Column(db.String)
    subscription_status = db.Column(db.String,default="Basic")
    membership_expire = db.Column(db.Date,nullable=True,default=None)

class Signals(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.String(1000))
    data_type = db.Column(db.String(100))
    file_name = db.Column(db.String(255))
    status = db.Column(db.String(100))
    
class Announcements(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.String(1000))
    data_type = db.Column(db.String(100))
    file_name = db.Column(db.String(255))
    status = db.Column(db.String(100))
    
class Price_Containers(db.Model):
    __tablename__ = 'Price_Containers'
    id = db.Column(db.Integer, primary_key=True)
    plan1 = db.Column(db.Integer)
    plan2 = db.Column(db.Integer)
    plan3 = db.Column(db.Integer)
    plan4 = db.Column(db.Integer)
    discount = db.Column(db.Integer)

@app.route('/')
def index():
    premium_members = Members.query.filter_by(subscription_status="Premium").all()
    basic_members = Members.query.filter_by(subscription_status="Basic").all()
    return render_template('index.html',members=premium_members, basic_members=basic_members)

@app.route('/add-signal',methods=['GET','POST'])
def add_signal():
    if request.method == 'POST':
        body = request.form['body']
        file = request.files["file"]
        file_name = file.filename
        status = "PENDING"
        data_type = 'text'
        if file:
            if file_name.split('.')[-1] in ['png', 'jpg', 'jpeg' 'gif','mp4', 'mov', 'avi', 'mkv']:
                if file_name.split('.')[-1] in ['png', 'jpg', 'jpeg' 'gif']:
                    data_type = 'image'
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
                    file.save(filepath)
                elif file_name.split('.')[-1] in ['mp4', 'mov', 'avi', 'mkv']:
                    data_type = 'video'
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
                    file.save(filepath)
                signal = Signals(body=body,data_type=data_type,file_name=file_name,status=status)
                db.session.add(signal)
                db.session.commit()
                print(f"New signal with name '{body[:10]}' successfully added to database")
                flash("New Signal added to database")
            else:
                flash("Unsupported file")
        else:
            signal = Signals(body=body,data_type=data_type,file_name='',status=status)
            db.session.add(signal)
            db.session.commit()
            print(f"New signal with name '{body[:10]}' successfully added to database")
            flash("New Signal added to database")
        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/add-announce',methods=['GET','POST'])
def add_announce():
    if request.method == 'POST':
        body = request.form['body']
        file = request.files["file"]
        file_name = file.filename
        status = "PENDING" 
        data_type = 'text'
        if file:
            if file_name.split('.')[-1] in ['png', 'jpg', 'jpeg' 'gif','mp4', 'mov', 'avi', 'mkv']:
                if file_name.split('.')[-1] in ['png', 'jpg', 'jpeg' 'gif']:
                    data_type = 'image'
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
                    file.save(filepath)
                elif file_name.split('.')[-1] in ['mp4', 'mov', 'avi', 'mkv']:
                    data_type = 'video'
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
                    file.save(filepath)
                announce = Announcements(body=body,data_type=data_type,file_name=file_name,status=status)
                db.session.add(announce)
                db.session.commit()
                print(f"New announce with name '{body[:10]}' successfully added to database")
                flash("New announce added to database")
            else:
                flash("Unsupported file")
        else:
            announce = Announcements(body=body,data_type=data_type,file_name='',status=status)
            db.session.add(announce)
            db.session.commit()
            print(f"New announce with name '{body[:10]}' successfully added to database")
            flash("New announce added to database")
        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))
    
@app.route('/add-member',methods=['GET','POST'])
def add_member():
    if request.method == 'POST':
        telegram_id = request.form['tg-id']
        membership_status = request.form['membership-status']
        expire_date = request.form['membership-expire-date']
        member = Members.query.filter_by(telegram_id=telegram_id).first()
        if not expire_date:
            flash(f"Select a valid expiration date")
            return redirect(url_for('index'))
        if member:
            print("Valid Member ID")
            member.subscription_status = membership_status
            member.membership_expire = datetime.strptime(expire_date, "%Y-%m-%d").date()
            db.session.commit()
            flash(f"{telegram_id} is now {membership_status.upper()} member")
        else:
            print("Member ID NOT Found at Database.")
            flash(f"Member ID {telegram_id} NOT Found at Database")
        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/add-discount',methods=['GET','POST'])
def add_discount():
    if request.method == 'POST':
        discount = int(request.form['discount'])
        price_container = Price_Containers.query.first()
        price_container.discount = discount
        db.session.commit()
        flash(f"Discount Updated to {discount}%")
        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))



if __name__ == "__main__":

    with app.app_context():   
        db.create_all()
    app.run(host='0.0.0.0')

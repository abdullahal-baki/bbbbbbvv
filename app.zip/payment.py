import time
import requests
from datetime import date, timedelta
from database import become_premium
API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjE4NjY5IiwiZXhwIjoxNzI1NDQ1MzE3fQ.CGVu79BmlXV6JNd1sIT9fGlpDOgu9InNSRL3vH67ItY'
BUSINESS_ID = '17397'
BASE_URL = f'https://api.hoodpay.io/v1/businesses/{BUSINESS_ID}'

TG_API="7089877258:AAFvL5ShLK7EvQ1k59iKYln5iXTfy0ibl_I"

def create_payment(amount, currency, description):
    print("Creating new payment request. Info: ",description)
    url = f'{BASE_URL}/payments'
    headers = {
        'Authorization': f'Bearer {API_KEY}',
        'Content-Type': 'application/json'
    }
    payload = {
        'amount': amount,
        'currency': currency,
        'description': description
    }
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()  
        if response.status_code == 201:
            payment_data = response.json()
            print('Payment created successfully!')
            print('Payment ID:', payment_data['id'])
            url,id = payment_data['url'], payment_data['id']
            open("log.txt","a").write(str(amount)+":"+currency+":"+url+"\n")
            return url, id
        elif response.status_code == 200:
            if response.json()['message'] == "Payment successfully created":
                print('Payment created successfully!')
                url = response.json()['data']['url']
                id = response.json()['data']['id']
                print("Payment URL: ",url)
                open("log.txt","a").write(str(amount)+":"+currency+":"+url+"\n")
                return url,id
            else:
                return None,response.status_code
        else:
            print('Failed to create payment')
            print('Status code:', response.status_code)
            print('Response:', response.json())
    except requests.exceptions.RequestException as e:
        print(f'An error occurred: {e}')

def send_payment_success_reply(chat_id,pay_id,expire):
    send_message = 'https://api.telegram.org/bot'+TG_API+'/sendMessage'
    payload={"chat_id":chat_id,"text":f"Your payment successful. Payment ID: {pay_id}.\n Your Premium membership will be expire on {expire}" }
    requests.post(send_message,json=payload)


def calculate_expiration_date(plan):
    today = date.today()
    if plan == 1:
        return today + timedelta(days=30)
    elif plan == 3:
        return today + timedelta(days=90)
    elif plan == 12:
        return today + timedelta(days=365)
    elif plan == 0:
        return today + timedelta(days=99999) 
    else:
        raise ValueError("Invalid subscription plan")


def check_payment_status(chat_id,payment_id,plan):
    for i in range(360):  # 30 MINUTE
        time.sleep(5)
        url = f'{BASE_URL}/payments/{payment_id}'
        headers = {
            'Authorization': f'Bearer {API_KEY}',
        }
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            if response.status_code == 200:
                payment_status = response.json()
                payment_status = payment_status["data"]['status']
                # print(f'Payment Status [{payment_id}]:', payment_status)
                if payment_status == "AWAITING_PAYMENT":
                    continue
                elif payment_status == "COMPLETED":
                    print(f'Payment Status [{payment_id}]:', payment_status)
                    expire = calculate_expiration_date(plan)
                    become_premium(chat_id,expire)
                    send_payment_success_reply(chat_id,payment_id,expire)
                    break
            else:
                print('Failed to check payment status')
                print('Status code:', response.status_code)
                print('Response:', response.json())
                continue
        except requests.exceptions.RequestException as e:
            print(f'An error occurred: {e}')
            continue
            

def cancel_payment(payment_id):
    url = f'{BASE_URL}/payments/{payment_id}/cancel'
    headers = {
        'Authorization': f'Bearer {API_KEY}',
    }

    try:
        response = requests.post(url, headers=headers)
        response.raise_for_status()  # Raise an error for bad status codes
        if response.status_code == 200:
            cancel_data = response.json()
            print('Payment canceled successfully!')
            print('Cancellation Details:', cancel_data)
            return cancel_data
        else:
            print('Failed to cancel payment')
            print('Status code:', response.status_code)
            print('Response:', response.json())
    except requests.exceptions.RequestException as e:
        print(f'An error occurred: {e}')

import logging
import os
import time
import warnings
import requests
from sqlalchemy import create_engine, Column, Integer, String, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)
warnings.filterwarnings("ignore", category=DeprecationWarning)
path = "instance/database.db"
engine = create_engine(f'sqlite:///{path}', echo=False)
Base = declarative_base()
class Signals(Base):
    __tablename__ = 'signals'
    id = Column(Integer, primary_key=True)
    body = Column(String(1000))
    data_type = Column(String(100))
    file_name = Column(String(255))
    status = Column(String(100))
    
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
# session = Session()
from contextlib import contextmanager

if not os.path.exists('id.txt'):
    with open('id.txt', 'w') as f:
        f.write('')

with open('id.txt', 'r', encoding='utf-8') as file:
    ids = file.read().splitlines()
    file.close()

@contextmanager
def get_session():
    session = Session()
    try:
        yield session
    finally:
        session.close()
def get_signals():
    with get_session() as session:
        signals = session.query(Signals).all()
        session.close()
        return signals
def send_signal():
    signals = get_signals()
    for signal in signals:
        id = signal.id
        body = signal.body
        if str(id) not in ids:
            try:
                send_message = 'https://api.telegram.org/bot6677119379:AAErpONHtvtGclRFrEvE8gX4M0Ezs8197LQ/sendMessage'
                payload={"chat_id":'1383909683',"text":body,"parse_mode":"Markdown" }
                requests.post(send_message,json=payload)
                payload={"chat_id":'961693042',"text":body,"parse_mode":"Markdown" }
                requests.post(send_message,json=payload)
                ids.append(str(id))
                with open('id.txt', 'a', encoding='utf-8') as file:
                    file.write(str(id)+'\n')
            except:
                pass
def main():
    while True:
        try:
            send_signal()
        except:
            pass
        time.sleep(1)
if __name__ == '__main__':
    main()
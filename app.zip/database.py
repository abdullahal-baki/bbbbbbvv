import logging
import warnings
from sqlalchemy import create_engine, Column, Integer, String, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError
from datetime import date
logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)
warnings.filterwarnings("ignore", category=DeprecationWarning)

engine = create_engine('sqlite:///instance/database.db', echo=False)
Base = declarative_base()

class Members(Base):
    __tablename__ = 'members'
    id = Column(Integer, primary_key=True)
    telegram_id = Column(String(255), unique=True)
    username = Column(String)
    name = Column(String)
    subscription_status = Column(String,default="Basic")
    membership_expire = Column(Date,nullable=True,default=None)

class Signals(Base):
    __tablename__ = 'signals'
    id = Column(Integer, primary_key=True)
    body = Column(String(1000))
    data_type = Column(String(100))
    file_name = Column(String(255))
    status = Column(String(100))
    
class Announcements(Base):
    __tablename__ = 'announcements'
    id = Column(Integer, primary_key=True)
    body = Column(String(1000))
    data_type = Column(String(100))
    file_name = Column(String(255))
    status = Column(String(100))
class Price_Containers(Base):
    __tablename__ = 'Price_Containers'
    id = Column(Integer, primary_key=True)
    plan1 = Column(Integer)
    plan2 = Column(Integer)
    plan3 = Column(Integer)
    plan4 = Column(Integer)
    discount = Column(Integer)
    
    
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

# session = Session()
from contextlib import contextmanager

@contextmanager
def get_session():
    session = Session()
    try:
        yield session
    finally:
        session.close()

def add_member(id,username, name, status="Basic", expire=None):
    with get_session() as session:
        existing_member = session.query(Members).filter_by(telegram_id=id).first()
        if existing_member:
            print(f"Error: A member with telegram_id {id} already exists.")
            return None
        new_member = Members(
            telegram_id=id,
            name=name,
            username = username,
            subscription_status=status,
            membership_expire=expire
        )
        try:
            session.add(new_member)
            session.commit()
            print(f"Member {name} added successfully.")
        except IntegrityError as e:
            session.rollback()
            print("An error occurred:", e)

def get_telegram_ids():
    with get_session() as session:
        telegram_ids = session.query(Members.telegram_id).all()
        session.close() 
        return [id for (id,) in telegram_ids]

def get_all_members():
    with get_session() as session:
        members = session.query(Members).all()
        session.close()
        return members
def get_member(user_id):
    with get_session() as session:
        member = session.query(Members).filter_by(telegram_id=user_id).first()
        session.close()
        return member

def become_premium(user_id,date):
    with get_session() as session:
        member = session.query(Members).filter_by(telegram_id=user_id).first()
        member.subscription_status = 'Premium'
        member.membership_expire = date
        session.commit()
        session.close()
        print(f"User [{user_id}] is now premium member.")
    
def become_basic(user_id):
    with get_session() as session:
        member = session.query(Members).filter_by(telegram_id=user_id).first()
        member.subscription_status = 'Basic'
        session.commit()
        session.close()
        print(f"User [{user_id}] is now basic member.")


def get_signals():
    with get_session() as session:
        signals = session.query(Signals).filter_by(status='PENDING').first()
        session.close()
        return signals

def update_signal(signal_id):
    with get_session() as session:
        signal = session.query(Signals).filter_by(id=signal_id).first()
        signal.status = 'SENT'
        session.commit()
        session.close()

def get_announcements():
    with get_session() as session:
        signals = session.query(Announcements).filter_by(status='PENDING').first()
        session.close()
        return signals

def update_announcements(announce_id):
    with get_session() as session:
        announce = session.query(Announcements).filter_by(id=announce_id).first()
        announce.status = 'SENT'
        session.commit()
        session.close()

def get_discount():
    with get_session() as session:
        discount = session.query(Price_Containers.discount).first()
        discount.discount
        session.close()
        return discount.discount

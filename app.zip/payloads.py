
def start_payload(chat_id,name):
    return {'chat_id': chat_id,
    'text':f'Hi {name}!',
    'reply_markup':{
        'keyboard': 
        [   [
            {'text': 'Membership Status'},
            {'text': 'Join'},
            ]
        ],
        "resize_keyboard": True
        }	
    }
    
def main_menu(chat_id):
    return {
    'chat_id': chat_id,
    'text': '''🚀 Maximize Profits with Our PREMIUM Signals!
        💡 Tutorials:
        📍 List All Available Commands: /help
        📍 Contact to support /support

        👑PREMIUM Plan Includes:
        💎 High-Accuracy Signals
        💎 3-10 Daily Crypto Signals
        💎 Up to 2000% Daily Profit
        💎 Beginner's Guide
        💎 Copy-Trade Signals
        💎 Entry, Take-Profit, and Stop Loss
        💎 Dedicated Support Team

        💬 Contact Us: @wssSupport or type /support directly to bot

        📣 Join our public channel /join
    '''
		}
    
def main_menu_for_member():
    return  '''🚀 Maximize Profits with Our PREMIUM Signals!
        💡 Tutorials:
        📍 List All Available Commands: /help
        📍 Contact to support /support

        👑PREMIUM Plan Includes:
        💎 High-Accuracy Signals
        💎 3-10 Daily Crypto Signals
        💎 Up to 2000% Daily Profit
        💎 Beginner's Guide
        💎 Copy-Trade Signals
        💎 Entry, Take-Profit, and Stop Loss
        💎 Dedicated Support Team

        💬 Contact Us: @wssSupport or type /support directly to bot

        📣 Join our public channel /join
    '''
    
def help():
    return '''Below you'll find a list with the commands available in this bot.

GENERAL
/help - Open the help menu.
/start - Get started - show the initial message.

SUBSCRIPTION
/join - Join the channels or groups.
/membershipstatus - Renew or cancel your subscription.
/subscribe - Become a member.
/support - Get admin support.
                            '''
def not_subscribe(chat_id):
    return {
    'chat_id': chat_id,
    'text': '''You will need to subscribe to become a member.''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[
                        [
						{
							"text": "Subscribe",
							"callback_data": "subscribe"
						}
                        ],
                        [
						{
							"text": "🔙 Back to the main menu",
							"callback_data": "main-menu"   
						}
                        ]
                
    ]
					}
		}

def subscribe_plan(chat_id,plan1,plan2,plan3,plan4,discount):
    return {
    'chat_id': chat_id,
    'text': '''Please select a plan from the list below:''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[
                        [
						{
							"text": f"WSS Signals: { f'$40➡️${plan1}' if discount > 0 else '$40'} /1 month",
							"callback_data": "signals-plan-1m"
						}
                        ],
                        [
						{
							"text": f"WSS Signals: { f'$90➡️${plan2}' if discount > 0 else '$90'} /3 month",
							"callback_data": "signals-plan-3m"
						}
                        ],
                        [
						{
							"text": f"WSS Signals: { f'$150➡️${plan3}' if discount > 0 else '$150'} /6 month",
							"callback_data": "signals-plan-1y"
						}
                        ],
                        [
						{
							"text": f"WSS Signals: { f'$250➡️${plan4}' if discount > 0 else '$250'} /Lifetime",
							"callback_data": "signals-plan-lifetime"
						}
                        ],
                        
                        [
						{
							"text": "🔙 Back to the main menu",
							"callback_data": "main-menu"   
						}
                        ]
                
    ]
					}
		}

def join_channel(chat_id):
        return {
            'chat_id': chat_id,
            'text': '''Click Below button to Join''',
            'reply_markup': 
                            {	
                                'inline_keyboard': 
                            [
                                [
                                {
                                    "text": "Click Here",
                                    "url": "https://t.me/wallstreetsquad"
                                }
                                ]
                        
            ]
                            }
                }

def member_subscription_status(expire_date):
    return f'''You are a premium member.
Your membership will expire: {expire_date}'''

#-----------individual plans--------------

def signals_plan_1m(chat_id,amount):
    return {
    'chat_id': chat_id,
    'text': f'''Wall Street Squad Signals
${amount} for 1 month (Manual renewal each 1 month)

By completing this order you will get access to the following chats:
📢 Wall Street Squad Signals PREMIUM 💎 High Leverage
📢 Wall Street Squad Signals PREMIUM 💎 Long Term
    ''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[[
						{
							"text": "Yes",
							"callback_data": "signals-plan-1m-confirm"
						},
						{
							"text": "No",
							"callback_data": "main-menu"
						}
                    ],
                    [
                        {
                            "text": "🔙 Back",
                            "callback_data": "subscribe"
                        }
                    ]
                        ]
					}
		}

def signals_plan_3m(chat_id,amount):
    return {
    'chat_id': chat_id,
    'text': f'''Wall Street Squad Signals
${amount} for 3 month (Manual renewal each 3 month)

By completing this order you will get access to the following chats:
📢 Wall Street Squad Signals PREMIUM 💎 High Leverage
📢 Wall Street Squad Signals PREMIUM 💎 Long Term
    ''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[[
						{
							"text": "Yes",
							"callback_data": "signals-plan-3m-confirm"
						},
						{
							"text": "No",
							"callback_data": "main-menu"
						}
                    ],
                    [
                        {
                            "text": "🔙 Back",
                            "callback_data": "subscribe"
                        }
                    ]
                        ]
					}
		}

def signals_plan_1y(chat_id,amount):
    return {
    'chat_id': chat_id,
    'text': f'''Wall Street Squad Signals
${amount} for 6 month (Manual renewal each 3 month)

By completing this order you will get access to the following chats:
📢 Wall Street Squad Signals PREMIUM 💎 High Leverage
📢 Wall Street Squad Signals PREMIUM 💎 Long Term
    ''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[[
						{
							"text": "Yes",
							"callback_data": "signals-plan-1y-confirm"
						},
						{
							"text": "No",
							"callback_data": "main-menu"
						}
                    ],
                    [
                        {
                            "text": "🔙 Back",
                            "callback_data": "subscribe"
                        }
                    ]
                        ]
					}
		}

def signals_plan_lifetime(chat_id,amount):
    return {
    'chat_id': chat_id,
    'text': f'''Wall Street Squad Signals
${amount} for lifetime

By completing this order you will get access to the following chats:
📢 Wall Street Squad Signals PREMIUM 💎 High Leverage
📢 Wall Street Squad Signals PREMIUM 💎 Long Term
    ''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[[
						{
							"text": "Yes",
							"callback_data": "signals-plan-lifetime-confirm"
						},
						{
							"text": "No",
							"callback_data": "main-menu"
						}
                    ],
                    [
                        {
                            "text": "🔙 Back",
                            "callback_data": "subscribe"
                        }
                    ]
                        ]
					}
		}


def signals_plan_confirm_message(chat_id,payment_page_url):
    return {
    'chat_id': chat_id,
    'text': '''Please click below button and confirm you payment.
    
Your payment process will be live track for 30 minutes. 
In this time we confirm your payment Automatically''',
    'reply_markup': 
					{	
						'inline_keyboard': 
					[[
                        {
                            "text": "Click Here to Proceed Payment",
                            "web_app": {
                                "url": payment_page_url
                            }
                        }
                        
                    ]]
					}
		}

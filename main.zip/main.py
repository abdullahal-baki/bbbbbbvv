import os
import re
import threading
import time
import requests
from telethon import TelegramClient, events
import os
import time
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.sync import TelegramClient
from telethon import functions, types
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.channels import InviteToChannelRequest
from telethon.tl.functions.messages import GetHistoryRequest
import telethon.sync
from datetime import datetime
from colorama import Fore
from telethon.tl.types import (
    PeerChannel,
    MessageEntityBold,
    MessageEntityItalic,
    MessageEntityTextUrl,
    MessageEntityUrl
)
from telethon.sync import TelegramClient
from telethon.tl.functions.messages import GetHistoryRequest
from telethon.tl.types import (
    PeerChannel
)







# [Johny](https://solscan.io/token/2T8VzQDbvqyUE6yXf6UoP4WNLsBmkGB1nQZkeegcpump) has entered [Finder Trending](https://t.me/FinderTrending/8) 💎

# C[hart
# ](https://dexscreener.com/solana/2T8VzQDbvqyUE6yXf6UoP4WNLsBmkGB1nQZkeegcpump)T[elegram](https://t.me/johnyofficialsol)
from license import check_expiration


API_ID = '21200382'
API_HASH = 'd557d4fb0824c9cab8c71c0496948f99'
USERNAME = 'shaimhoulader'
PHONE_NUMBER = '+8801627924787'
RECEIVER_USERNAME = 'alamin2327'

client = TelegramClient(PHONE_NUMBER, API_ID, API_HASH)

# track_path = os.path.join(os.getcwd(),'checked.txt')
# if not os.path.exists(track_path):
#     open(track_path, 'w').close()
    
# with open(track_path, 'r', encoding='latin-1') as f:
#     checked_tokens = f.read().splitlines()

checked_tokens = []
    
channel_username = 'findertrending'
private_channel_id = 'https://t.me/+rhGHHQ3Gi-Q0MGFk'

def extract_token(message):
    # print(message)
    url_pattern = re.compile(r'https?://[^\s)]+')
    urls = url_pattern.findall(message)
    for url in urls:
        if 'solscan.io' in url:
            token = url.split('/')[-1]
            return token
        
def parse_entities(message):
    if not message.message:
        return ""
    message_text = message.message
    entities = message.entities or []
    parsed_text = message_text
    offset = 0
    
    for entity in entities:
        start = entity.offset + offset
        length = entity.length
        end = start + length
        text = parsed_text[start:end]
        if isinstance(entity, MessageEntityTextUrl):
            parsed_text = parsed_text[:start] + f"[{text}]({entity.url})" + parsed_text[end:]
            offset += len(f"[{text}]({entity.url})") - length
    return parsed_text
        
async def main():
    await client.start()
    if not await client.is_user_authorized():
        await client.send_code_request(PHONE_NUMBER)
        try:
            await client.sign_in(PHONE_NUMBER, input('Enter the code: '))
        except SessionPasswordNeededError:
            await client.sign_in(password=input('Password: '))
    print('[+] Successfully Logged in...\n')
    time.sleep(3)
    checked = 1
    await client.send_message(private_channel_id,'Program successfully initialized')
    while True:
        try:
            channel_entity= await client.get_entity(channel_username)
            posts = await client(GetHistoryRequest(
                peer=channel_entity,
                limit=1,
                offset_date=None,
                offset_id=0,
                max_id=0,
                min_id=0,
                add_offset=0,
                hash=0))
            
            print(f'Post scrapped: {checked}',end='\r')
            checked +=1
            
            for message in posts.messages:
                parse_message = parse_entities(message)
                token = extract_token(parse_message)
                if token and token not in checked_tokens:
                    print('[+] New Token: ',token)
                    await client.send_message(private_channel_id,token)
                    checked_tokens.append(token)
                    # with open(track_path, 'a') as ff:
                    #     ff.write(f'{token}\n')
                    print("\n\n------------------------------------------------------\n\n")
        except Exception as e:
            print(e)
        time.sleep(0.8)


if __name__ == '__main__':
    day = 18
    month = 7
    if check_expiration(day,month):
        print("Starting The program..")
        with client:
            client.loop.run_until_complete(main())
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
import datetime
import time
import requests
import json
def check_expiration(day, month, year=2024):
    expiration_date = datetime.date(year, month, day)
    try:
        json_response = requests.get("http://worldtimeapi.org/api/timezone/Asia/Dhaka")
        data = json_response.json()
        datetime_str = data['datetime']
        datetime_obj = datetime.datetime.fromisoformat(datetime_str)
        current_day = datetime_obj.day
        current_month = datetime_obj.month
        current_year = datetime_obj.year
        current_date = datetime.date(current_year, current_month, current_day)
        if current_date > expiration_date:
            print( '\033[91m'+ "\nThis program has expired. Please contact with developer.\n" + '\033[0m')
            time.sleep(10)
            return False
        else:
            return True
    except Exception as e:
        print( '\033[91m'+ "\nNo INTERNET Connection.\n" + '\033[0m')
        time.sleep(10)
        return False
    
if __name__ == '__main__':
    day = 6
    month = 6
    if check_expiration(day,month):
        print("working...")